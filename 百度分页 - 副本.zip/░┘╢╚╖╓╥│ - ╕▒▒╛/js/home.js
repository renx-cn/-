window.onload = function () {//页面加载完后执行
  pag();
};

function pag() {
  let li = document.querySelectorAll('.pag ul .number a');
  for (const key in li) {
    li[key].onclick = function () {
      for (const key in li) {
        li[key].className = '';
      }
      this.classList.add('active');
    }
  }
}